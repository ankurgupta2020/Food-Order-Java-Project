var searchData=
[
  ['ratings_0',['Ratings',['../classfood__odering_1_1user_1_1_ratings.html',1,'food_odering::user']]],
  ['register_1',['register',['../classfood__odering_1_1user_1_1register.html',1,'food_odering::user']]],
  ['restaurant_2',['restaurant',['../classfood__odering_1_1user_1_1restaurant.html',1,'food_odering::user']]]
];
