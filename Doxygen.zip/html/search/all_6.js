var searchData=
[
  ['order_0',['Order',['../classfood__odering_1_1user_1_1_order.html',1,'food_odering::user']]]
];
