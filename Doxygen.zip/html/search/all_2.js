var searchData=
[
  ['item_0',['item',['../classfood__odering_1_1user_1_1item.html',1,'food_odering::user']]]
];
