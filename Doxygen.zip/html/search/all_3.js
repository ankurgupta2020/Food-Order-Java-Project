var searchData=
[
  ['login_0',['login',['../classfood__odering_1_1user_1_1login.html',1,'food_odering::user']]]
];
