var searchData=
[
  ['main_0',['main',['../classfood__odering_1_1user_1_1main.html',1,'food_odering::user']]]
];
