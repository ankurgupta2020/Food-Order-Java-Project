var searchData=
[
  ['validate_0',['Validate',['../classfood__odering_1_1user_1_1_validate.html',1,'food_odering::user']]]
];
