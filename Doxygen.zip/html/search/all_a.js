var searchData=
[
  ['upi_0',['UPI',['../classfood__odering_1_1user_1_1_u_p_i.html',1,'food_odering::user']]]
];
