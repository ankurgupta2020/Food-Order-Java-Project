package food_odering.user;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class main {

    public static void main(String[] args) throws SQLException{
        Scanner sc = new Scanner(System.in);
        int flag=0;
		cart c  = new cart();
        String user_id="";
        System.out.println("====================================");
        System.out.println("Welcome to the Food Ordering Portal");
        System.out.println("====================================");
        System.out.println();
        System.out.println("Please select your option!!");
        System.out.println("1. Login");
        System.out.println("2. Create a new Account");
        System.out.println("3. Exit");
            	
        int choice = sc.nextInt();
        int u_id = 0;
            switch (choice){
           
                case 1: System.out.println("Welcome to Login Portal");
                        login log = new login();
                       // log.signup();
                        log.setname(sc);
                        log.setPassword(sc);
                        user_id = log.conn_register();
                        if (user_id!="") {
	                        System.out.println("User_id :"+user_id);
	                        restaurant r = new restaurant();
	                        int r_id = r.viewRestaurant(user_id);
	                        item i= new item();
	                        u_id = getUserId(user_id);
	                        Tracking.CalculateEstimatedDeliveryTime(u_id, r_id);
	               		 	i.viewItems(r_id);
	               			cart_func c1  = new cart_func();
	               			while(true) {
		               			System.out.println("Please select from the following options");
		               			
		               			System.out.println("1. Add item(s) to Cart");
		               			System.out.println("2. Delete item(s) from Cart");
		               			System.out.println("3. View Cart");
		               			System.out.println("4. Discard the entire order");
		               			System.out.println("5. Proceed for Payment");
		               			System.out.println("6. Exit");
		               			
		               			int ch = sc.nextInt();
		               			if (ch ==1) {
		               				c1.AddtoCart(user_id,r_id);
		               			}
		               			else if (ch==2){
		               				System.out.println("Enter the item id you want to delete");
		               				int itid = sc.nextInt();
		               				c1.delete_item(user_id, r_id, itid);
		               			}
		               			else if (ch ==3) {
		               				c1.displayCart(user_id, r_id);
		               			}
		               			else if(ch==4) {
		               				c1.delete_cart_all_items(user_id, r_id);
		          
		               				
		               			}
		               			else if(ch==5) {
			               			 try {
	//		                           Class.forName("com.mysql.jdbc.Driver");
			               			   u_id = getUserId(user_id);
			                           Payment_main.proceed(u_id,r_id);
			                           //Need to check whether the payment is successful or not
			               			   c1.delete_cart_all_items(user_id, r_id);

			                           
			                           
			                       }
			                       catch(Exception e) {
			                           System.out.print("Do not connect to DB - Error:"+e);
			                       }
		               				
		               				
		               			}
		               			
		               			else if(ch==6) {
		               				break;
		               			}
		               			else if(ch==8) {
			               			u_id = getUserId(user_id);
		               				Tracking.CalculateEstimatedDeliveryTime(u_id, r_id);
		               			}
//		               		 	break;
	               		}
                        }
                        break;
                case 2: System.out.println("Welcome to Registration Portal");
                        register reg = new register();
                        reg.setFirstname(sc);
                        reg.validate();
                        reg.setLastname(sc);
                        reg.validate_2();
                        reg.setname(sc);
                        reg.validate_3();
                        reg.setPassword(sc);
                        reg.validate_10();
                        reg.setRePassword(sc);
                        reg.validate_11();
                        reg.setNumber(sc);
                        reg.validate_4();
                        reg.setEmailId(sc);
                        reg.validate_5();
                        reg.setCountry(sc);
                        reg.validate_6();
                        reg.setCity(sc);
                        reg.validate_7();
                        reg.setState(sc);
                        reg.validate_8();
                        reg.setPincode(sc);
                        reg.validate_9();
                        
                        reg.conn();
                        break;

                case 3: System.out.println("bbye");
                        flag=1;
                        break;
     
                
                default: System.out.println("invalid option");
            }
        }
    public static int getUserId(String Username) throws SQLException {
    	java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");            // prepare statement		
		int userid = 0;
		String query1 = "Select * from cust where UserName = ?";
	    java.sql.PreparedStatement preparedStmt1 =  con.prepareStatement(query1);
	    preparedStmt1.setString (1, Username);
		ResultSet result1 = preparedStmt1.executeQuery();
		
	    if(result1.next()) {
			  userid = result1.getInt("User_id");
		 }
    	return userid;
    	
    	
    }
    

    
}
