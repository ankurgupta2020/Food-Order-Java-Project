package food_odering.user;

public abstract class payment_mode {
	
	public abstract void details(int userId);
	
	public abstract void getPayment();
	
	
}
