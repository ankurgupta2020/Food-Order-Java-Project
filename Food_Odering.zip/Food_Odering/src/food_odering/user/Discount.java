package food_odering.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author kadia
 */
public class Discount {
  
     public void update_discount(String user) throws SQLException {
    	 
    	java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");            // prepare statement		
 		int userid = 0;
 		String query1 = "Select * from cust where UserName = ?";
 	    java.sql.PreparedStatement preparedStmt1 =  con.prepareStatement(query1);
 	    preparedStmt1.setString (1, user);
 		ResultSet result1 = preparedStmt1.executeQuery();
 		
 	    if(result1.next()) {
 			  userid = result1.getInt("User_id");
 		 } 
    	 
    	 
    	
        String update_dis = "insert into discount(userid,SAVE20, SAVE50) values(?,1,1)  ";
        try{
            
            //Class.forName("com.mysql.cj.jdbc.Driver");
                // prepare statement
                
                PreparedStatement pstatement = con.prepareStatement(update_dis);
                
                pstatement.setInt(1,userid);
                //pstatement.executeUpdate();
                int res = pstatement.executeUpdate();
                
                if(res > 0){
                    System.out.println("Success");
                }
                
                
        }
        catch (SQLException throwables) {
                throwables.printStackTrace();
            }
    }
    
}
