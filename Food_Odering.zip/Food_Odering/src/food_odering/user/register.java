/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package food_odering.user;

/**
 *
 * @author kadia
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;
import java.util.regex.Pattern;

public class register {
    Scanner sc = new Scanner(System.in);
    protected String FirstName;
    protected String LastName;
    protected String UserName;
    protected String Password;
    protected String RePassword;
    protected String ContactNo;
    protected String EmailId;
    protected String Pincode;
    protected String City;
    protected String State;
    protected String Country;
    
    
         public void setFirstname(Scanner sc){
               System.out.println("Enter First Name:: ");
               FirstName = sc.next();
           }
        public String getFirstname(){
               return FirstName;
           }

        public void setLastname(Scanner sc){
               System.out.println("Enter Last Name:: ");
               LastName = sc.next();
           }
        public String getLastname(){
               return LastName;
           }

        public void setname(Scanner sc){
            System.out.println("Enter username:: ");
            UserName = sc.next();
        }
        public String getname(){
            return UserName;
        }

        public void setPassword(Scanner sc){
            System.out.println("Enter password:: ");
            Password = sc.next();
        }
        public String getPassword(){
            return Password;
        }
        
        public void setRePassword(Scanner sc){
            System.out.println("Enter confirm password:: ");
            RePassword = sc.next();
        }
        public String getRePassword(){
            return RePassword;
        }
        
        
        public void setNumber(Scanner sc){
            System.out.println("Enter contact number:: ");
            ContactNo = sc.next();
        }
        public String getNumber(){
            return ContactNo;
        }
        
         public void setEmailId(Scanner sc){
        System.out.println("Enter email id:: ");
        EmailId = sc.next();
        }
        public String getEmailId(){
            return EmailId;
        }
        
         public void setCountry(Scanner sc){
        System.out.println("Enter your Country:: ");
        Country = sc.next();
        }
        public String getCountry(){
            return Country;
        }
        
         public void setCity(Scanner sc){
        System.out.println("Enter you City:: ");
        City = sc.next();
        }
        public String getCity(){
            return City;
        }
        
         public void setState(Scanner sc){
        System.out.println("Enter your State:: ");
        State = sc.next();
        }
        public String getState(){
            return State;
        }

         public void setPincode(Scanner sc){
            System.out.println("Enter Pincode:: ");
            Pincode = sc.next();
        }
        public String getPincode(){
            return Pincode;
        }
 
       

        public void validate(){
            
            if(!FirstName.matches("^[A-Z][a-zA-Z]*$")){
                System.out.println("Please enter your valid first name");
                while (!FirstName.matches("^[A-Z][a-zA-Z]*$")){
                    setFirstname(sc);
                }
            }
        }
            
        public void validate_2(){
             if(!LastName.matches("^[A-Z][a-zA-Z]*$")){
                System.out.println("Please enter your valid last name");
                while (!LastName.matches("[A-Z][a-zA-Z]*")){
                    setLastname(sc);
                }
            }
         }
        
        public void validate_3(){
            if(!UserName.matches("^[A-Za-z]\\w{5,29}$")){
                System.out.println("Please enter your valid user name");
                while (!UserName.matches("^[A-Za-z]\\w{5,29}$")){
                    setname(sc);
                }
            }
        }
        
        public void validate_4(){
            if(!ContactNo.matches("^(0/91)?[7-9][0-9]{9}$")){
                System.out.println("Please enter valid 10 digits mobile number");
                while(!ContactNo.matches("^(0/91)?[7-9][0-9]{9}$")){
                    setNumber(sc);
                }
                
           }
        }
        
        public void validate_5(){
             if(!EmailId.matches("^(.+)@(.+)$")){
                System.out.println("Please enter your valid email id");
                 while(!EmailId.matches("^(.+)@(.+)$"))
                  {setEmailId(sc);}
            }
            
        }
        
        public void validate_6(){
            if(!Country.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                System.out.println("Please enter your valid residency address");
                while(!Country.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                    setCountry(sc);
                }
            }
        }
        
        public void validate_7(){
            if(!City.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                System.out.println("Please enter your valid city name");
                while(!City.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                    setCity(sc);
                }
            }
        }
        
        public void validate_8(){
            if(!State.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                System.out.println("PLease enter your valid state name");
                while(!State.matches("^([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)$")){
                    setState(sc);
                }
            }
        }
        
        public void validate_9(){
            if(!Pincode.matches("^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$")){
                System.out.println("Please enter your area's valid pincode");
                while(!Pincode.matches("^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$")){
                    setPincode(sc);
                }
            }
        }
      // Minimum eight characters, at least one letter, one number and one special character:  
        public void validate_10(){
            if(!Password.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$")){
              System.out.println("Enter password according to given conditions");
              while(!Password.matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$")){
                  setPassword(sc);
              }
          }
        }
          
        public void validate_11(){
            if(!Password.equals(RePassword)){
              System.out.println("Your password doesn't match");
              while(!Password.equals(RePassword)){
                  setRePassword(sc);
              }
          }
        }
     
        public void conn() {
            
            if (Validate.checkUserName(UserName)) {
                    System.out.println("The User Name is already registered");
            }
            
            else{
            String query = "insert into cust(FirstName, LastName, UserName, Password, RePassword, ContactNo, EmailId, Country, City, State, Pincode) values(?,?,?,?,?,?,?,?,?,?,?)";
            try {
                //Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");

                // prepare statement
                PreparedStatement pstatement = con.prepareStatement(query);
                
                    pstatement.setString(1, FirstName);
                    pstatement.setString(2, LastName);
                    pstatement.setString(3, UserName);
                    pstatement.setString(4, Password);
                    pstatement.setString(5, RePassword);
                    pstatement.setString(6, ContactNo);
                    pstatement.setString(7, EmailId);
                    pstatement.setString(8, Country);
                    pstatement.setString(9, City);
                    pstatement.setString(10, State);
                    pstatement.setString(11, Pincode);
                   


                //pstatement.executeUpdate();
                pstatement.executeUpdate();

                if(Password.equals(RePassword)){
                    
                       System.out.println(FirstName + " with " + UserName + " has been successfully registered ");
                       Discount dis =  new Discount();
                       dis.update_discount(UserName);
                   }
               

               else{
                   System.out.println("sorry invalid username or password!! Please try again");
               }

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
           }
        }
    
}
