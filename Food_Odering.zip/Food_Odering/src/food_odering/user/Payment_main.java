package food_odering.user;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
public class Payment_main {
	static Scanner myObj = new Scanner(System.in);

    
    

    public static void proceed(final int userId,int rest_id) throws SQLException {
    	java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerdatabase", "root", "");

		 try {
	            String query = "SELECT * FROM cart WHERE User_Id = '" + userId + "'";
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(query);
	            Double price = 0d;
	            while (rs.next())
	            {
	              Float costPrice = 0f;
	              int itemId = rs.getInt("Item_Id");
	              int quantity = rs.getInt("Quantity");
	              String query2 = "SELECT * FROM item WHERE Item_Id = '" + itemId + "' and Restaurant_Id  = '"+rest_id+"'";
		            Statement st2 = conn.createStatement();

	              ResultSet rs2 = st2.executeQuery(query2);
	              while (rs2.next()) {
	            	  costPrice = rs2.getFloat("Price");
	              }
	              rs2.close();

	              price += costPrice * quantity;
  	            }

	            
	            if(price<100) {
	            	System.out.println("Order amount can't be below 100\nPlease enter more items to proceed");
	            	//Add cart item insert
	            	return;
	            }
	            
	            
	            Double deliveryCharge = 0d;
	            deliveryCharge = calculateDeliveryCharge(userId, rest_id, st);
	            //Entry in order table and order_item table price deliverycharge , discount , total cost
	           
	    		
//	    		System.out.println("Order Details \n Item cost - %d \n Delivery charges - %d \n Discount - %d" +
//	    				" \n Total Amount - %d \n Please press 1 to proceed to payment \n PLease press 2 to cancel ");
//	    		TODO: remove the below line, fix the above line set suitable varialbe give 3 options 1- proceed 3- cancel 2- discount
	            Double dis = 0d;
	            Double amount = price+deliveryCharge-dis;
	            System.out.println("----------- Order Details -------------");
	    		System.out.printf("\nItem cost - %.2f \nDelivery charges - %.2f \nDiscount - %.2f \n-----------------------------\nTotal Amount - %.2f \n-----------------------------",price,deliveryCharge, dis, amount);
//	            System.out.println("---------------------------------------");
	            System.out.println(" \nPlease press 1 to apply coupon  \nPlease press 2 to proceed for payment");
	            
	            String orderQuery = "SELECT * FROM `order` where userid = '" + userId + "' and OrderStatus = '" + "Payment Pending" + "'";
	            int orderId =0;
	            ResultSet result = st.executeQuery(orderQuery);
	            while(result.next()) {
	            	orderId = result.getInt("OrderId");
	            }
	            String input = myObj.nextLine();
	            switch (input) {
	              case "1":
	                dis = applyDiscount(userId, orderId, st);
	                break;
	            }
	            
	            amount = price+deliveryCharge-dis;
	            
	            String insertQuery = "insert into `order`(OrderStatus, TotalAmount, Discount, DeliveryCharge, TotalBill, userid,RestaurantId) values(?,?,?,?,?,?,?)";
	    		try {
	    			PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);
	    			preparedStatement.setString(1, "Payment Pending");
	    			preparedStatement.setDouble(2, price);
	    			preparedStatement.setDouble(3, dis);
	    			preparedStatement.setDouble(4, deliveryCharge);
	    			preparedStatement.setDouble(5, amount);
	    			preparedStatement.setInt(6,userId);
	    			preparedStatement.setInt(7, rest_id);
	    			int x = preparedStatement.executeUpdate();


	    		} catch (SQLException exception) {
	    			exception.printStackTrace();
	    		}	       
	    		orderQuery = "SELECT * FROM `order` where userid = '" + userId + "' and OrderStatus = '" + "Payment Pending" + "'";
	    		result = st.executeQuery(orderQuery);
	            while(result.next()) {
	            	orderId = result.getInt("OrderId");
	            }
	    		System.out.println("--------------------------");
	    		System.out.println("Order Details - ");
	    		System.out.println("--------------------------");
	    		System.out.printf("Item cost - %.2f \nDelivery charges - %.2f \nDiscount - %.2f\n----------------------------\nTotal Amount - %.2f \n----------------------------\n",price,deliveryCharge, dis, amount);
//	    		System.out.println("---------------------------");
	    			proceedToCheckout(userId, st , amount,orderId,conn);
	    			System.out.println("Order is confirmed!!!!");
	    			System.out.println("Your order is on the way!!!!!");
	    			Tracking.Track_Order(userId, rest_id, orderId);
	    			System.exit(0);

	            
	           
	        }
	        catch(Exception e) {
	            System.out.print("Do not connect to DB - Error:"+e);
	            e.printStackTrace();
	        }
		
	}
	
	public static Double calculateDeliveryCharge(final int userId, final int restrauntId, final Statement st) throws SQLException {

		double dist = Tracking.CalculateEstimatedDeliveryDistance(userId, restrauntId);
		double charge =0d;
		if(dist<=2) {
		        charge = dist*15; 
		       }
		else if(dist >2 && dist <= 5) {
		        charge = dist *12;
		       }
		else
			 charge = dist*11;
		     

		return (charge);
	}
	
	public static double applyDiscount(final int userId,final int orderId,final Statement st) {
		String query = "SELECT * FROM `discount` where userid = '" + userId +  "'";
				
        ResultSet result;
        int save50=0;
        int save20=0;
        double dis =0d;
		try {
			result = st.executeQuery(query);
			 while(result.next()) {
				save50 = result.getInt("SAVE50");
				save20 = result.getInt("SAVE20");
			 }
			 String updateQuery = "";
			 if(save50 == 1 && save20 == 1) {
				 
				 System.out.println("Promo codes available\n1.SAVE50\n2.SAVE20");
				 System.out.println("Enter the option to apply: ");
				
				 String ch = myObj.nextLine();
				 if(ch.equals("1")) {
					 updateQuery = "Update `discount` set `SAVE50`= 0 where userid='"+userId+"'";
					 dis = 50;
				 }
				 else {
					 dis = 20;
					 updateQuery = "Update `discount` set `SAVE20`= 0 where userid='"+userId+"'";
				 }
				 st.executeUpdate(updateQuery);

			 }
			 else if(save20 == 1) {
				 System.out.println("Promo codes available\n1.SAVE20");
				 System.out.println("SAVE20 promo code applied");
				 dis =20;
				 updateQuery = "Update `discount` set `SAVE20`= 0 where userid='"+userId+"'";
				 st.executeUpdate(updateQuery);

			 }
			 else if(save50==1) {
				 System.out.println("Promo codes available\n1.SAVE50");
				 System.out.println("SAVE50 promo code applied");
				 dis= 50;
				 updateQuery = "Update `discount` set `SAVE50`= 0 where userid='"+userId+"'";
				 st.executeUpdate(updateQuery);
			 }
			 else {
				 System.out.println("No promo codes available");
			 }
			 
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dis;
                

	}
	
	public static void proceedToCheckout(final int userId, final Statement st, final Double amount, final int orderId, final Connection connection) {

		//Scanner sc = new Scanner(System.in);
		System.out.println("Please select a payment mode - \n1.Credit Card \n2.Debit Card \n3.UPI \n4.NetBanking");

		String mode = myObj.nextLine();

		switch(mode) {
			case "1":
				mode="Credit Card";
				break;
			case "2":
				mode="Debit Card";
				break;
			case "3":
				mode="UPI";
				break;
			case "4":
				mode = "NetBanking";
				break;
			default:
		}

		String query = "INSERT into payment(orderId, amount, userId, mode, status) values (?,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, orderId);
			preparedStatement.setDouble(2, amount);
			preparedStatement.setInt(3, userId);
			preparedStatement.setString(4, mode);
			preparedStatement.setString(5, "PENDING");
			preparedStatement.executeUpdate();
			
			String paymentIdQuery = "SELECT * FROM `payment` where userid = '" + userId + "' and orderId = '" + orderId + "'";
			
            ResultSet result = st.executeQuery(paymentIdQuery);
            Payment p = new Payment();
            
            while(result.next()) {
            	p.setUserId(result.getInt("userid"));
            	p.setAmount(result.getDouble("amount"));
            	p.setMode(result.getString("mode"));
            	p.setPaymentId(result.getInt("PaymentId"));
            	p.setOrderId(result.getInt("orderId"));
            	p.setStatus(result.getString("status"));
            	
            }
            System.out.println(p.getPaymentId() +" "+ p.getStatus());
         
            switch(p.getMode()) {
			case "Credit Card":
				CreditCard c = new CreditCard();
				String creditQuery = "SELECT * FROM `creditcard` where UserId = '" + userId + "'";
				
	            result = st.executeQuery(creditQuery);
	            if(!result.next()) {
	            	System.out.println("Your credit card details is not stored in the database \n Please enter the following details for further proceedings:");
	            	c.details(userId);
	            	
	            }
	            result = st.executeQuery(creditQuery);
	            while(result.next()) {
	            	c.setCreditCardNo(result.getString("CardNo"));
	            	c.setPass(result.getString("Pass"));
	            	c.setUserId(result.getInt("UserId"));
	            }
				c.getPayment();
				break;
			case "Debit Card":
				DebitCard d = new DebitCard();
				String debitQuery = "SELECT * FROM `debitcard` where UserId = '" + userId + "'";
				
	            result = st.executeQuery(debitQuery);
	            if(!result.next()) {
	            	System.out.println("Your Debit card details is not stored in the database \n Please enter the following details for further proceedings:");
	            	d.details(userId);
	            	
	            }
	            result = st.executeQuery(debitQuery);
	            while(result.next()) {
	            	d.setdebitCardNo(result.getString("CardNo"));
	            	d.setPass(result.getString("Pass"));
	            	d.setUserId(result.getInt("UserId"));
	            }
				d.getPayment();
				
				break;
			case "UPI":
				UPI u = new UPI();
				String upiQuery = "SELECT * FROM `UPI` where UserId = '" + userId + "'";
				
	            result = st.executeQuery(upiQuery);
	            if(!result.next()) {
	            	System.out.println("Your UPI details is not stored in the database \n Please enter the following details for further proceedings:");
	            	u.details(userId);
	            	
	            }
	            result = st.executeQuery(upiQuery);
	            while(result.next()) {
	            	
	            	u.setupiId(result.getString("UPI_ID"));
	            	u.setPass(result.getString("Pass"));
	            	u.setUserId(result.getInt("UserId"));
	            }
				u.getPayment();
				
				break;
			case "NetBanking":
				NetBank n = new NetBank();
				String netBankQuery = "SELECT * FROM `netbanking` where userid = '" + userId + "'";
				
	            result = st.executeQuery(netBankQuery);
	            if(!result.next()) {
	            	System.out.println("Your NetBanking  details is not stored in the database \n Please enter the following details for further proceedings:");
	            	n.details(userId);
	            	
	            }
	            result = st.executeQuery(netBankQuery);
	            while(result.next()) {
	            	n.setAccNo(result.getString("acct_no"));
	            	n.setPass(result.getString("pass"));
	            	n.setUserId(result.getInt("userid"));
	            }
				n.getPayment();
				
				break;
			default:
		}
            
//            String updateQ = "Update `payment` set `status`= '"+"Payment Done"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
//            st.executeUpdate(updateQ);
//            updateQ = "Update `order` set `OrderStatus`= '"+"Order Confirmed"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
//            st.executeUpdate(updateQ);
            String updateQ = "Update `payment` set `status`= '"+"Payment Done"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
            st.executeUpdate(updateQ);
            updateQ = "Update `order` set `OrderStatus`= '"+"Order Confirmed"+"', `PaymentId`= '"+p.getPaymentId()+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
            st.executeUpdate(updateQ);      
            
		} catch (SQLException exception) {
			exception.printStackTrace();
		}

	}
}