package food_odering.user;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

//import com.mysql.jdbc.ResultSet;
import java.sql.ResultSet;
import java.sql.SQLException;

public class item extends restaurant {

	private int item_id;
	private String item_name;
	private int Price;
	private int quantity;
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	
	public void viewItems(int restId) throws SQLException {
		
//		int restId = super.viewRestaurant(username);
//		setItem_id(restId); 
		java.sql.Connection connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
		int id;
		
		String query4 = "SELECT * FROM item WHERE Restaurant_Id = ?";
		String item="";
		int pr=0;
		PreparedStatement ps4 = connection.prepareStatement(query4);
		ps4.setInt(1,restId);
		ResultSet result = ps4.executeQuery();
		while(result.next()) {
			 id = result.getInt("Item_id");
			 item = result.getString("Item_name");
			 pr = result.getInt("Price");
			 System.out.println("ID : "+ id  +"\n" +"Item Name: "+item);
			 System.out.println("Item Price: "+pr);
			 System.out.println();	 
		 }
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	
	
	
	
	
	
	
	
}
