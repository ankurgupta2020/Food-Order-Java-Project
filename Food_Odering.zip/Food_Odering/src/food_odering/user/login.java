/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package food_odering.user;

/**
 *
 * @author kadia
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class login {

    Scanner sc = new Scanner(System.in);
    String regname;
    String regpass;

    public void setname(Scanner sc){
        System.out.println("Enter username:: ");
        regname = sc.next();

    }

    public String getname(){
        return regname;
    }

    public void setPassword(Scanner sc){
        System.out.println("Enter password:: ");
        regpass = sc.next();

    }

    public String getPassword(){
        return regpass;
    }

    public String conn_register(){
        String s ="";
    	String query = "SELECT UserName, Password FROM cust WHERE UserName = ? AND Password = ?";
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
        	java.sql.Connection con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");            // prepare statement
            PreparedStatement pstatement = con.prepareStatement(query);

            pstatement.setString(1, regname);
            pstatement.setString(2, regpass);

            java.sql.ResultSet result =  pstatement.executeQuery();

             if(result.next()){
                System.out.println("login is successful");
                s = result.getString("UserName");
                return s;
                
            }
            else{
                System.out.println("invalid username or password");
            }
             
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return s;
    }
}
