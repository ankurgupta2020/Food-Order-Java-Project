package food_odering.user;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//import com.mysql.jdbc.PreparedStatement;

public class cart {
	
	private item[] cart;
	private String user_id;
	private String restaurant_id;
	public item[] getCart() {
		return cart;
	}
	public void setCart(item[] cart) {
		this.cart = cart;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getRestaurant_id() {
		return restaurant_id;
	}
	public void setRestaurant_id(String restaurant_id) {
		this.restaurant_id = restaurant_id;
	
	}
	//Will  fetch all the cart 
	public void addToCart(String username,int rest_ID,int item_ID,int q , int price) throws SQLException {
			
		java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
		
		int userid = 0;
		String query1 = "Select * from cust where UserName = ?";
	    java.sql.PreparedStatement preparedStmt1 =  conn.prepareStatement(query1);
	    preparedStmt1.setString (1, username);
		ResultSet result1 = preparedStmt1.executeQuery();
		
	    if(result1.next()) {
			  userid = result1.getInt("User_id");
		 }
		
		String query = "INSERT INTO `cart` (`User_id`, `Restaurant_id`, `Item_id`, `Quantity`, `Price`) VALUES (? , ? , ?, ?, ?)";
		java.sql.PreparedStatement preparedStmt =  conn.prepareStatement(query);
	     preparedStmt.setInt (1, userid);
	     preparedStmt.setInt (2, rest_ID);
	     preparedStmt.setInt (3, item_ID);
	     preparedStmt.setInt (4, q);
	     preparedStmt.setInt (5, price);
	     preparedStmt.execute();
	}
	
//	public void AddtoCart(String user_id,int rest_id) throws SQLException {		 
//		 Scanner scn = new Scanner(System.in);
//		 List<Integer> itemid=new ArrayList<Integer>(); 
//		 List<Integer> quantity=new ArrayList<Integer>(); 
////		 List<Integer> price=new ArrayList<Integer>(); 
//		
//		 while(true) {
//			 System.out.print("Enter item id you want to add?");
//			 int item =scn.nextInt();
//			 itemid.add(item);
//			 
//			 System.out.print("Enter Quantity ");
//			 int quan =scn.nextInt();
//			 quantity.add(quan);
//
//			 
//		
//			 System.out.println("Do you want to add more items in Cart ? ");
//			 String s = scn.next();
//			 addToCart(user_id ,rest_id, item , quan,0);
//			 if(s.equals("N") || s.equals("No") ) {
//				 break;		 
//			 }
//			 
//		 }
//	
//		 
//	}
	//delete from cart
	
	
		
		
		
		
		
		
		
	
	//Display items from cart
	public void display_item() {
		
		
		
	}
	
	//
	
	
	
	public void Cart_Item() {
		
		
		
		
	}
	
	
	
	
	
	
}