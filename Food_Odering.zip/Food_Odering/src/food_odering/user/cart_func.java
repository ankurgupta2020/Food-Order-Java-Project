package food_odering.user;

import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;


class cart_func {
	
	
	public void AddtoCart(String user_id,int rest_id) throws SQLException {
		 cart c  = new cart();
		 int price=0;
		 Scanner scn = new Scanner(System.in);
		 List<Integer> itemid=new ArrayList<Integer>(); 
		 List<Integer> quantity=new ArrayList<Integer>(); 
//		 List<Integer> price=new ArrayList<Integer>(); 
		 Connection connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
		 
		 while(true) {
			 System.out.print("Enter item id you want to add?");
			 int item =scn.nextInt();
			 itemid.add(item);
			 
			 System.out.print("Enter Quantity ");
			 int quan =scn.nextInt();
			 quantity.add(quan);
			 System.out.println("Do you want to add more items in Cart ? ");
			 String s = scn.next();
			 
			 String query = "SELECT * FROM item WHERE Item_id =? AND Restaurant_Id = ?";
			 PreparedStatement ps1 = connection.prepareStatement(query);
			 ps1.setInt(1,item);
			 ps1.setInt(2,rest_id);
			 ResultSet result1 = ps1.executeQuery();
			 if(result1.next()) {
				  price = result1.getInt("Price");
				  
			 }
			 
			 c.addToCart(user_id ,rest_id, item , quan,price);
			 if(s.equals("N") || s.equals("No") ) {
				 break;		 
			 }
			 else {
				 continue;
			 }
			 
		 }
	}
		 
	
		public void displayCart(String userId,int rest_ID) throws SQLException {
			java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
			
			int userid = 0;
			String query1 = "Select * from cust where UserName = ?";
		    java.sql.PreparedStatement preparedStmt1 =  conn.prepareStatement(query1);
		    preparedStmt1.setString (1, userId);
			ResultSet result1 = preparedStmt1.executeQuery();
			 if(result1.next()) {
				  userid = result1.getInt("User_id");
			 }
			
			String query = "Select * from cart inner join item on item.Item_id = cart.Item_id where item.Restaurant_id = cart.Restaurant_id and item.Restaurant_Id =? and cart.User_id =?";
			PreparedStatement ps2 = conn.prepareStatement(query);
			ps2.setInt(1,rest_ID);
			ps2.setInt(2, userid);
			ResultSet result2 = ps2.executeQuery();
			System.out.println("----------------DISPLAYING CART------------");
			while(result2.next()) {
				 System.out.println("Item Name : "+result2.getString("Item_name"));
				 int quan = result2.getInt("Quantity");
				 System.out.println("Quantity : "+quan);
				 System.out.println("Price: "+ quan* result2.getInt("Price"));
			 }
			System.out.println("---------------------------------------------");
		}
			
	
	
		 public void delete_item(String userID, int rest_ID,int itemID) {
				
				try {
					java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");

					int userid =0;
					String query1 = "Select * from cust where UserName = ?";
				    java.sql.PreparedStatement preparedStmt1 =  conn.prepareStatement(query1);
				    preparedStmt1.setString (1, userID);
					ResultSet result1 = preparedStmt1.executeQuery();
					 if(result1.next()) {
						  userid = result1.getInt("User_id");
					 }
					String query = "delete from cart where User_id = ? and Restaurant_id = ? and item_id = ?";
					java.sql.PreparedStatement preparedStmt =  conn.prepareStatement(query);
					preparedStmt.setInt (1, userid);
				    preparedStmt.setInt (2, rest_ID);
				    preparedStmt.setInt (3, itemID);
				    preparedStmt.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 }
		 public void delete_cart_all_items(String userID, int rest_ID) {
				
				try {
					java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");

					int userid =0;
					String query1 = "Select * from cust where UserName = ?";
				    java.sql.PreparedStatement preparedStmt1 =  conn.prepareStatement(query1);
				    preparedStmt1.setString (1, userID);
					ResultSet result1 = preparedStmt1.executeQuery();
					 if(result1.next()) {
						  userid = result1.getInt("User_id");
					 }
				
					String query = "delete from cart where User_id = ? and Restaurant_id = ? ";
					java.sql.PreparedStatement preparedStmt =  conn.prepareStatement(query);
					preparedStmt.setInt (1, userid);
				    preparedStmt.setInt (2, rest_ID);
				    preparedStmt.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 }
		 
		 
		
		
	
	
	
	
	
	
	

}
