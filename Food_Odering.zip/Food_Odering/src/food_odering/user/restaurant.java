package food_odering.user;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import com.mysql.jdbc.Connection;

public class restaurant {
	private int RestaurantId;
	private String RestaurantName;
	private String state; 
	
	
	
	public int viewRestaurant(String username) throws SQLException {
//		 String state = "";
		 int restId=0 ;
		 String ItemName ="";
		 int Price = 0;
		 java.sql.Connection connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
		 String query1 = "SELECT * FROM cust WHERE UserName =?";
		 PreparedStatement ps1 = connection.prepareStatement(query1);
		 ps1.setString(1,username);
		 ResultSet result1 = ps1.executeQuery();
		 if(result1.next()) {
			 setState(result1.getString("State"));
		 }
		 System.out.println("Showing restaurants for State: "+getState());
		 System.out.println();
	     String query = "SELECT * FROM restaurant WHERE state =?";
         PreparedStatement ps = connection.prepareStatement(query);
         ps.setString(1, getState());
         ResultSet result = ps.executeQuery();
         
//         Print all restaurants in particular state
         String rest_name = null;
         System.out.println("Restaurants avaialable in City: ");
   
         int i= 1;
         while(result.next())
         {
        	 rest_name = result.getString("Restaurant_Name");
        	 System.out.println(i+". "+rest_name);
        	 i++;
         }
         Scanner scn = new Scanner(System.in);
         System.out.println("Enter the restaurant you want to eat in:");
//         Input from user restaurant he is interested in
         String rest = scn.nextLine();
         System.out.println(rest);
         String query3 = "SELECT * FROM restaurant WHERE Restaurant_Name = ?";
         PreparedStatement ps3 = connection.prepareStatement(query3);
         ps3.setString(1,rest);
         result = ps3.executeQuery();
         if(result.next()) {
        	 restId = result.getInt("Restaurant_Id");
         }
         System.out.println("Resaturant Id :"+restId);
         System.out.println();
         
         return restId;
//		 String query4 = "SELECT * FROM item WHERE Restaurant_Id = ?";
//		 
//		 PreparedStatement ps4 = connection.prepareStatement(query4);
//		 ps4.setInt(1,restId);
//		 result = ps4.executeQuery();
//		 while(result.next()) {
//			 ItemName = result.getString("Item_name");
//			 Price = result.getInt("Price");
//			 System.out.println("Item Name: "+ItemName);
//			 System.out.println("Item Price: "+Price);
//			 System.out.println();	 
//		 }
		
	}

	public int getRestaurantId() {
		return RestaurantId;
	}

	public void setRestaurantId(int restaurantId) {
		RestaurantId = restaurantId;
	}

	public String getRestaurantName() {
		return RestaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		RestaurantName = restaurantName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
	
	
	
	
	

}
