/*
i * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package food_odering.user;

import java.sql.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author kadia
 */
public class Validate {
    
    protected static boolean validFName(String FirstName){
         String val_fname = "^[A-Z][a-zA-Z]*$";
        Pattern p = Pattern.compile(val_fname);
        if (FirstName == null) {
            return false;
        }
        Matcher m = p.matcher(FirstName);
        return m.matches();
    }
    
        
    protected static boolean validLName(String LastName){
         String val_lname = "^[A-Z][a-zA-Z]*$";
        Pattern p = Pattern.compile(val_lname);
        if (LastName == null) {
            return false;
        }
        Matcher m = p.matcher(LastName);
        return m.matches();
    }
    protected static boolean validUName(String UserName){
        String val_uname = "^[A-Za-z]\\w{5,29}$";
        Pattern p = Pattern.compile(val_uname);
        if (UserName == null) {
            return false;
        }
        Matcher m = p.matcher(UserName);
        return m.matches();
    }
    
    protected static boolean validPass(String Password){
        String val_pass = "^(?=.*[0-9])"
                       + "(?=.*[a-z])(?=.*[A-Z])"
                       + "(?=.*[@#$%^&+=])"
                       + "(?=\\S+$).{8,20}$";
        Pattern p = Pattern.compile(val_pass);
        if (Password == null) {
            return false;
        }
        Matcher m = p.matcher(Password);
        return m.matches();
    }
    
    //check for user name exsists or not
    protected static boolean checkUserName(String UserName) {

        boolean checkUser = false;
        String query = "SELECT * FROM cust WHERE UserName =?";

        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");
            PreparedStatement Pstatement = connection.prepareStatement(query);
            //ps = MyConnection.getConnection().prepareStatement(query);
            Pstatement.setString(1, UserName);

            ResultSet result = Pstatement.executeQuery();

            if(result.next())
            {
                checkUser = true;
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return checkUser;

    }

    
}
