package food_odering.user;

import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Tracking {
	static double toRadians( double degree)
	{
	    
	    double one_deg = (Math.PI) / 180;
	    return (one_deg * degree);
	}

	
	public static double CalculateEstimatedDeliveryDistance(int userId,int RestaurantId) throws SQLException {
    	java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerdatabase", "root", "");
        Statement st = conn.createStatement();
        String query = "SELECT * FROM `U_location` where userid = '" + userId +  "'";
		ResultSet result;
		        double u_lat =0d;
		        double u_lon = 0d;
		        double r_lat =0d;
		        double r_lon = 0d;
		        double dist =0d;
		try {
		result = st.executeQuery(query);
		while(result.next()) {
		u_lat = result.getDouble("lat");
		u_lon= result.getDouble("lon");
		}
		query = "SELECT * FROM `R_location` where RestaurantId = '" + RestaurantId +  "'";
		result = st.executeQuery(query);
		while(result.next()) {
		r_lat = result.getDouble("lat");
		r_lon= result.getDouble("lon");
		}
		
		double latitude1 = toRadians(u_lat);
	    double longitude1 = toRadians(u_lon);
	    double latitude2 = toRadians(r_lat);
	    double longitude2 = toRadians(r_lon);
	    double d_long = longitude2 - longitude1;
	    double d_lat = latitude2 - latitude1;
	 
	    dist = Math.pow(Math.sin(d_lat / 2), 2) +
	                          Math.cos(latitude1) * Math.cos(latitude2) *
	                          Math.pow(Math.sin(d_long / 2), 2);
	 
	    dist = 2 * Math.asin(Math.sqrt(dist));
	    double R = 6371;   
	    dist = dist * R;	
	    System.out.format("Distance from Restaurant: %.2f", dist);
	    System.out.println();
		
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	
		return dist;
	}	
	public static double CalculateEstimatedDeliveryTime(int userId,int RestaurantId) throws SQLException {
		double dist = CalculateEstimatedDeliveryDistance(userId,RestaurantId);
		double eta =0d;
	    if(dist<=3) {
	        eta = dist*10;
	       }
	    else if(dist >3 && dist <= 6) {
	        eta = dist *15;
	       }
	    else
	        eta = dist*16;
	
	    System.out.format("Estimated Time of Arrival: %.2f", eta); 
	    System.out.println();
	    return eta;
	    
	}
	public static void Track_Order(int userId,int RestaurantId,int orderId) throws SQLException, InterruptedException {
		   Scanner scn = new Scanner(System.in);
		   double eta = CalculateEstimatedDeliveryTime(userId,RestaurantId);
		   List<Double> givenList = Arrays.asList(eta,eta+1);
	       Random rand = new Random();
	       Double delivered_time = givenList.get( rand.nextInt(givenList.size()));
	       java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerdatabase", "root", "");
	       Statement st = conn.createStatement();
	       if (delivered_time== eta){
	    	TimeUnit.SECONDS.sleep(10);
	        System.out.println("Order Delivered.");
	        String updateQ = "Update `order` set `OrderStatus`= '"+"Order Delivered"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
	           st.executeUpdate(updateQ);
	           Ratings r = new Ratings();
	           r.UserRating(RestaurantId,userId);
	       }
	       else {
	    	TimeUnit.SECONDS.sleep(12);
	        System.out.println("Order is taking longer than usual to be delivered!!");
	        System.out.println("Do you want to cancel your order ?(Y/N):");
	        String ch = scn.next();
	        if(ch.equals("Y")) {
	        System.out.println("Your order is cancelled");
	        System.out.println("Refund will be processed soon!!");
	        System.out.println("Keep ordering!!!");
	        String updateQ = "Update `order` set `OrderStatus`= '"+"Order Cancelled"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
	           st.executeUpdate(updateQ);
	           updateQ = "Update `payment` set `status`= '"+"Refund processed"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
	           st.executeUpdate(updateQ);
	        }
	        else {
	        	TimeUnit.SECONDS.sleep(5);
	            System.out.println("Order late Delivered.");
	            Ratings r = new Ratings();
	            r.UserRating(RestaurantId,userId);
	            String updateQ = "Update `order` set `OrderStatus`= '"+"Order Delivered"+"' where userid = '" + userId + "' and orderId = '" + orderId + "'";
	           st.executeUpdate(updateQ);
	        }
	       }
	       scn.close();
		
		
		
	}
	

}
