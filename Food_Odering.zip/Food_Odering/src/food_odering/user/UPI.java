package food_odering.user;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UPI extends payment_mode{
	static Scanner myObj = new Scanner(System.in);
	private String upiId;
	private String pass;
	private int userId;
	public String getupiId() {
		return upiId;
	}
	public void setupiId(String upiId) {
		this.upiId = upiId;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public int getUserId() {
		return userId;
		
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public void details(int userId) {
		System.out.println("Enter UPI Id: ");
		String upi = myObj.next();
		System.out.println("Enter password : ");
		String password = myObj.next();
		String query = "INSERT into UPI(UPI_ID, UserId, Pass) values (?,?,?)";
		try {
        	java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");            // prepare statement
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, upi);
			preparedStatement.setInt(2, userId);
			preparedStatement.setString(3, password);
			
			preparedStatement.executeUpdate();
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
	}
	public void getPayment() {
		System.out.println("Please proceed for payment");
		System.out.println("Enter UPI Id: ");
		String upi = myObj.next();
		System.out.println("Enter password : ");
		String password = myObj.next();
		while(validateupi(upi)==0 || validatePass(password)==0) {
			System.out.println("UPI details is not correct\n Please enter correct details");
			System.out.println("Enter UPI Id: ");
			upi = myObj.next();
			System.out.println("Enter password : ");
			password = myObj.next();
		}
		
		//update order status
		//update payment table
		System.out.println("Payment done!!");
		
	}
	public int validateupi(String cno) {
		
		if(cno.equals(this.upiId)) 
			
			
			return 1;
		return 0;
	}
	public int validatePass(String password) {
		
		if(password.equals(this.pass))
			return 1;
		return 0;
	}

}
