package food_odering.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Ratings extends restaurant {
	
	private int ratings;
	private int app_rating;

	public int getRatings() {
		return ratings;
	}

	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	
	public void UserRating(int rest_id,int user_id) throws SQLException {
		System.out.println("Please enter rating from 1 to 5 for restaurant food");
		Scanner scn = new Scanner(System.in);
		ratings  = scn.nextInt();
		System.out.println("Let us know how much you liked our service?");
		app_rating = scn.nextInt();
		System.out.println("Thank you for your feedback :)");
		Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");

		String query = "INSERT INTO `ratings` (`Restaurant_id`, `User_id`, `Rating`,`App_rating`) VALUES (? , ? , ?, ?)";
		java.sql.PreparedStatement preparedStmt =  conn.prepareStatement(query);
	     preparedStmt.setInt (1, rest_id);
	     preparedStmt.setInt (2, user_id);
	     preparedStmt.setInt (3, ratings);
	     preparedStmt.setInt (4, app_rating);
	     preparedStmt.execute();
		scn.close();
	}

	public int getApp_rating() {
		return app_rating;
	}

	public void setApp_rating(int app_rating) {
		this.app_rating = app_rating;
	}

	

}
