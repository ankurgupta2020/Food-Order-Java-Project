package food_odering.user;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;




public class DebitCard extends payment_mode{
	static Scanner myObj = new Scanner(System.in);

	public String getdebitCardNo() {
		return debitCardNo;
	}
	public void setdebitCardNo(String debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	private String debitCardNo;
	private String pass;
	private int userId;
	public void details(int userId) {
		System.out.println("Enter debit card number: ");
		String debitcard = myObj.next();
		System.out.println("Enter password : ");
		String password = myObj.next();
		String query = "INSERT into debitcard(CardNo, UserId, Pass) values (?,?,?)";
		try {
        	java.sql.Connection conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/customerDatabase", "root", "");            // prepare statement

			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, debitcard);
			preparedStatement.setInt(2, userId);
			preparedStatement.setString(3, password);
			
			preparedStatement.executeUpdate();
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
	}
	public void getPayment() {
		System.out.println("Please proceed for payment");
		System.out.println("Enter debit card number: ");
		String debitcard = myObj.next();
		System.out.println("Enter password : ");
		String password = myObj.next();
		while(validateCard(debitcard)==0 || validatePass(password)==0) {
			System.out.println("Debit Card details is not correct\n Please enter correct details");
			System.out.println("Enter debit card number: ");
			debitcard = myObj.next();
			System.out.println("Enter password : ");
			password = myObj.next();
		}
		System.out.println("Payment done!!");
		
	}
	public int validateCard(String cno) {
		if(cno.equals(debitCardNo))
			
			return 1;
		return 0;
	}
	public int validatePass(String password) {
		if(password.equals(pass))
			return 1;
		return 0;
	}
}
